# Architecture du Système - Application Web de Réponse aux Appels d'Offres

## 1. Vue d'Ensemble de l'Architecture

L'application sera développée selon une architecture moderne, modulaire et évolutive, basée sur le framework Next.js. Cette architecture permettra une séparation claire des responsabilités et facilitera la maintenance et les évolutions futures.

### 1.1 Architecture Globale

```
┌─────────────────────────────────────────────────────────────┐
│                  Application Web Next.js                     │
├───────────┬───────────────┬────────────────┬────────────────┤
│ Interface │ Gestion des   │ Analyse et     │ Génération     │
│ Utilisateur│ Produits      │ Comparaison    │ de Rapports    │
└───────────┴───────────────┴────────────────┴────────────────┘
        │             │               │               │
        ▼             ▼               ▼               ▼
┌─────────────────────────────────────────────────────────────┐
│                     API Backend                              │
├───────────┬───────────────┬────────────────┬────────────────┤
│ Auth &    │ Gestion       │ Traitement     │ Services       │
│ Sécurité  │ Documents     │ Données        │ PDF            │
└───────────┴───────────────┴────────────────┴────────────────┘
        │             │               │               │
        ▼             ▼               ▼               ▼
┌─────────────────────────────────────────────────────────────┐
│                  Base de Données D1                          │
├───────────┬───────────────┬────────────────┬────────────────┤
│ Utilisateurs│ Produits     │ CPS & Exigences│ Rapports       │
└───────────┴───────────────┴────────────────┴────────────────┘
```

## 2. Choix Technologiques

### 2.1 Frontend
- **Framework** : Next.js avec React
- **Styles** : Tailwind CSS pour une interface responsive et moderne
- **Composants** : Bibliothèque de composants personnalisée
- **Visualisation** : Recharts pour les graphiques et visualisations
- **Gestion d'état** : React Context API et hooks personnalisés

### 2.2 Backend
- **API** : API Routes de Next.js
- **Authentification** : NextAuth.js pour la gestion des utilisateurs
- **Traitement de documents** : Bibliothèques spécialisées pour l'extraction de texte
- **Génération de PDF** : WeasyPrint pour des rapports de haute qualité

### 2.3 Base de Données
- **Type** : D1 (SQLite) via Cloudflare Workers
- **ORM** : Drizzle ORM pour la gestion des modèles et requêtes
- **Migrations** : Système de migrations intégré

### 2.4 Déploiement
- **Hébergement** : Cloudflare Pages avec Workers
- **CI/CD** : GitHub Actions pour l'intégration et le déploiement continus

## 3. Structure des Modules

### 3.1 Module d'Interface Utilisateur
- Tableau de bord
- Gestion des CPS
- Gestion des produits
- Visualisation des comparaisons
- Génération et consultation des rapports
- Administration des utilisateurs

### 3.2 Module de Gestion des Produits
- Import et stockage des datasheets
- Extraction des caractéristiques techniques
- Gestion des versions et variantes
- Catégorisation par modalité médicale

### 3.3 Module d'Analyse et Comparaison
- Extraction des exigences des CPS
- Algorithmes de correspondance
- Calcul des scores de compatibilité
- Suggestions de produits optimaux

### 3.4 Module de Génération de Rapports
- Création de templates de rapports
- Génération dynamique de PDF
- Personnalisation des rapports
- Export multi-formats

## 4. Modèles de Données

### 4.1 Modèle Utilisateur
```
User {
  id: string (primary key)
  name: string
  email: string
  role: enum (admin, commercial, technique, gestionnaire)
  password: string (hashed)
  createdAt: datetime
  updatedAt: datetime
}
```

### 4.2 Modèle Produit
```
Product {
  id: string (primary key)
  name: string
  modality: enum (mammographe, amplificateur, table)
  version: string
  manufacturer: string
  description: text
  datasheetUrl: string
  createdAt: datetime
  updatedAt: datetime
}

ProductCharacteristic {
  id: string (primary key)
  productId: string (foreign key)
  category: string
  name: string
  value: string
  unit: string
  importance: enum (critical, standard, optional)
  createdAt: datetime
  updatedAt: datetime
}
```

### 4.3 Modèle CPS
```
CPS {
  id: string (primary key)
  title: string
  reference: string
  organization: string
  deadline: datetime
  documentUrl: string
  status: enum (new, analyzed, in_progress, completed)
  createdAt: datetime
  updatedAt: datetime
}

Requirement {
  id: string (primary key)
  cpsId: string (foreign key)
  category: string
  description: text
  importance: enum (mandatory, optional)
  section: string
  page: integer
  createdAt: datetime
  updatedAt: datetime
}
```

### 4.4 Modèle Comparaison
```
Comparison {
  id: string (primary key)
  cpsId: string (foreign key)
  productId: string (foreign key)
  overallScore: float
  status: enum (draft, validated, rejected)
  createdBy: string (foreign key to User)
  createdAt: datetime
  updatedAt: datetime
}

ComparisonDetail {
  id: string (primary key)
  comparisonId: string (foreign key)
  requirementId: string (foreign key)
  characteristicId: string (foreign key)
  match: boolean
  score: float
  comment: text
  createdAt: datetime
  updatedAt: datetime
}
```

### 4.5 Modèle Rapport
```
Report {
  id: string (primary key)
  comparisonId: string (foreign key)
  title: string
  format: enum (pdf, excel, html)
  fileUrl: string
  createdBy: string (foreign key to User)
  createdAt: datetime
  updatedAt: datetime
}
```

## 5. Flux de Données et Processus

### 5.1 Processus d'Analyse d'un CPS
1. Import du document CPS
2. Extraction automatique du texte
3. Identification et catégorisation des exigences
4. Validation manuelle des exigences extraites
5. Stockage des exigences dans la base de données

### 5.2 Processus de Gestion des Produits
1. Import des datasheets produits
2. Extraction des caractéristiques techniques
3. Validation et enrichissement manuel des caractéristiques
4. Stockage dans la base de données produits

### 5.3 Processus de Comparaison
1. Sélection d'un CPS et d'un ou plusieurs produits
2. Exécution de l'algorithme de correspondance
3. Génération des scores de compatibilité
4. Présentation des résultats avec mise en évidence des conformités/non-conformités
5. Validation manuelle des résultats

### 5.4 Processus de Génération de Rapport
1. Sélection d'une comparaison validée
2. Choix du template de rapport
3. Personnalisation des options (sections, niveau de détail, etc.)
4. Génération du PDF avec WeasyPrint
5. Stockage et mise à disposition du rapport

## 6. Sécurité et Performance

### 6.1 Sécurité
- Authentification sécurisée avec NextAuth.js
- Autorisation basée sur les rôles
- Protection contre les attaques CSRF, XSS
- Chiffrement des données sensibles
- Journalisation des actions importantes

### 6.2 Performance
- Optimisation des requêtes de base de données
- Mise en cache des données fréquemment utilisées
- Traitement asynchrone des tâches longues (analyse de documents)
- Pagination des résultats volumineux
- Optimisation des images et assets

## 7. Évolutivité et Maintenance

### 7.1 Stratégie d'Évolution
- Architecture modulaire permettant l'ajout de nouvelles modalités médicales
- API bien documentée pour faciliter les intégrations futures
- Tests automatisés pour garantir la stabilité lors des évolutions

### 7.2 Maintenance
- Journalisation complète pour faciliter le diagnostic des problèmes
- Documentation technique détaillée
- Procédures de sauvegarde et restauration
- Monitoring des performances et de la disponibilité

## 8. Intégrations Externes

### 8.1 Intégrations Potentielles
- API pour l'import/export de données depuis des systèmes externes
- Webhooks pour notifier des événements importants
- Intégration avec des services d'OCR avancés pour l'extraction de texte
- Connecteurs pour systèmes CRM ou ERP existants
