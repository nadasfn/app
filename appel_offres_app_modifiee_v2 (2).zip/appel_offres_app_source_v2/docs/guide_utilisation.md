# Guide d'utilisation - Application de Réponse aux Appels d'Offres

## Introduction

Ce guide d'utilisation vous présente les principales fonctionnalités de l'Application de Réponse aux Appels d'Offres, conçue pour automatiser l'analyse des Cahiers des Prescriptions Spéciales (CPS) et la comparaison des exigences avec les caractéristiques techniques des produits d'imagerie médicale.

## Fonctionnalités principales

### 1. Tableau de bord

Le tableau de bord vous donne une vue d'ensemble de votre activité :
- Nombre de produits par modalité
- CPS récemment importés
- Comparaisons récentes
- Statistiques de conformité

### 2. Gestion des produits

#### Importation de datasheets
1. Accédez à la section "Produits" dans le menu principal
2. Cliquez sur "Ajouter un produit"
3. Sélectionnez la modalité (Amplificateur de brillance, Mammographe ou Table de radiologie)
4. Remplissez les informations de base (fabricant, modèle)
5. Téléchargez le datasheet au format PDF
6. Cliquez sur "Analyser le datasheet"
7. Vérifiez et complétez les caractéristiques extraites automatiquement
8. Cliquez sur "Enregistrer le produit"

#### Consultation des produits
- Filtrez les produits par modalité, fabricant ou modèle
- Cliquez sur un produit pour voir ses caractéristiques détaillées
- Utilisez les options d'édition ou de suppression si nécessaire

### 3. Gestion des CPS

#### Importation de CPS
1. Accédez à la section "CPS" dans le menu principal
2. Cliquez sur "Ajouter un CPS"
3. Remplissez les informations de base (référence, organisation)
4. Téléchargez le CPS au format PDF
5. Cliquez sur "Analyser le CPS"
6. Vérifiez les lots et exigences extraits automatiquement
7. Cliquez sur "Enregistrer le CPS"

#### Consultation des CPS
- Filtrez les CPS par référence, organisation ou date
- Cliquez sur un CPS pour voir ses lots et exigences détaillées
- Utilisez les options d'édition ou de suppression si nécessaire

### 4. Comparaisons et rapports

#### Création d'une comparaison
1. Accédez à la section "Comparaisons" dans le menu principal
2. Cliquez sur "Nouvelle comparaison"
3. Sélectionnez un CPS dans la liste
4. Sélectionnez un ou plusieurs produits à comparer
5. Cliquez sur "Lancer la comparaison"
6. Consultez les résultats de la comparaison

#### Génération de rapports
1. Dans la page de résultats de comparaison
2. Cliquez sur "Générer un rapport PDF"
3. Le rapport sera automatiquement téléchargé
4. Vous pouvez également accéder aux rapports précédents depuis la section "Rapports"

## Astuces et bonnes pratiques

### Pour l'importation des datasheets
- Utilisez des PDF de bonne qualité pour une meilleure extraction
- Vérifiez toujours les caractéristiques extraites automatiquement
- Complétez manuellement les caractéristiques manquantes

### Pour l'importation des CPS
- Assurez-vous que le CPS est bien structuré pour une meilleure extraction
- Vérifiez que les lots et exigences sont correctement identifiés
- Ajoutez manuellement les exigences manquantes si nécessaire

### Pour les comparaisons
- Commencez par comparer un seul produit à la fois
- Vérifiez les résultats de conformité pour chaque exigence
- Utilisez les filtres pour vous concentrer sur les exigences non conformes

## Dépannage rapide

### Problèmes d'extraction de datasheets
- Vérifiez que le PDF n'est pas protégé ou corrompu
- Essayez de convertir le PDF en texte avant l'importation
- Utilisez l'option d'ajout manuel des caractéristiques

### Problèmes d'extraction de CPS
- Vérifiez que le CPS est au format PDF texte (non scanné)
- Assurez-vous que la structure du CPS est standard
- Utilisez l'option d'ajout manuel des exigences

### Problèmes de génération de rapports
- Vérifiez que WeasyPrint est correctement installé
- Assurez-vous que tous les champs obligatoires sont remplis
- Consultez les logs d'erreur pour plus de détails

## Conclusion

Cette application vous permet de gagner un temps considérable dans l'analyse des appels d'offres et la préparation des réponses. N'hésitez pas à consulter la documentation d'installation pour plus de détails sur la configuration et la personnalisation de l'application.
