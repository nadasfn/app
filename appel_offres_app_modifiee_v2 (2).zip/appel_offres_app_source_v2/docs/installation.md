# Documentation d'Installation et d'Utilisation
# Application de Réponse aux Appels d'Offres

## Table des matières

1. [Introduction](#introduction)
2. [Prérequis](#prérequis)
3. [Installation](#installation)
4. [Configuration](#configuration)
5. [Utilisation](#utilisation)
6. [Structure du projet](#structure-du-projet)
7. [Dépannage](#dépannage)
8. [FAQ](#faq)

## Introduction

L'Application de Réponse aux Appels d'Offres est un outil conçu pour automatiser l'analyse des Cahiers des Prescriptions Spéciales (CPS) et la comparaison des exigences avec les caractéristiques techniques des produits d'imagerie médicale. L'application prend en charge trois modalités principales :

- Amplificateurs de brillance
- Mammographes
- Tables de radiologie télécommandées

Cette application permet de :
- Importer et analyser des datasheets de produits
- Importer et analyser des CPS
- Comparer automatiquement les exigences des CPS avec les caractéristiques des produits
- Générer des rapports PDF de conformité

## Prérequis

Avant d'installer l'application, assurez-vous que votre système dispose des éléments suivants :

- Node.js (version 16.x ou supérieure)
- npm (version 8.x ou supérieure)
- Python 3.8+ (pour WeasyPrint)
- WeasyPrint (pour la génération de PDF)
- Git (optionnel, pour le clonage du dépôt)

### Installation des prérequis

#### Node.js et npm

Téléchargez et installez Node.js depuis [le site officiel](https://nodejs.org/).

#### Python et WeasyPrint

```bash
# Installation de Python
sudo apt-get update
sudo apt-get install python3 python3-pip

# Installation des dépendances de WeasyPrint
sudo apt-get install build-essential python3-dev python3-pip python3-setuptools python3-wheel python3-cffi libcairo2 libpango-1.0-0 libpangocairo-1.0-0 libgdk-pixbuf2.0-0 libffi-dev shared-mime-info

# Installation de WeasyPrint
pip3 install weasyprint
```

## Installation

### Option 1 : Installation à partir du dépôt Git

```bash
# Cloner le dépôt
git clone https://github.com/votre-organisation/appel-offres-app.git
cd appel-offres-app

# Installer les dépendances
npm install

# Construire l'application
npm run build
```

### Option 2 : Installation à partir du fichier ZIP

1. Téléchargez le fichier ZIP de l'application
2. Extrayez le contenu dans le répertoire de votre choix
3. Ouvrez un terminal dans ce répertoire
4. Exécutez les commandes suivantes :

```bash
# Installer les dépendances
npm install

# Construire l'application
npm run build
```

## Configuration

### Configuration de la base de données

L'application utilise une base de données SQLite via Cloudflare D1. Pour initialiser la base de données :

```bash
# Initialiser la base de données
npx wrangler d1 execute DB --local --file=migrations/0001_initial.sql

# Appliquer les migrations
npx wrangler d1 migrations apply DB --local
```

### Configuration de l'environnement

Créez un fichier `.env.local` à la racine du projet avec les variables suivantes :

```
# Configuration de l'application
APP_NAME=Appel Offres App
APP_ENV=production
APP_URL=http://localhost:3000

# Configuration de la base de données
DB_CONNECTION=sqlite
DB_DATABASE=appel_offres.db

# Configuration des rapports PDF
PDF_TEMP_DIR=/tmp
```

## Utilisation

### Démarrage du serveur de développement

```bash
npm run dev
```

L'application sera accessible à l'adresse [http://localhost:3000](http://localhost:3000).

### Démarrage du serveur de production

```bash
npm start
```

### Utilisation dans VS Code

1. Ouvrez le dossier du projet dans VS Code
2. Installez les extensions recommandées (optionnel)
   - ESLint
   - Prettier
   - Tailwind CSS IntelliSense
3. Ouvrez un terminal intégré et exécutez `npm run dev`

## Structure du projet

```
projet_appel_offres/
├── appel_offres_app/
│   ├── migrations/            # Fichiers de migration de la base de données
│   │   └── 0001_initial.sql   # Schéma initial de la base de données
│   ├── public/                # Fichiers statiques
│   ├── src/
│   │   ├── app/               # Pages de l'application Next.js
│   │   │   ├── page.js        # Page d'accueil
│   │   │   ├── produits/      # Pages de gestion des produits
│   │   │   ├── cps/           # Pages de gestion des CPS
│   │   │   └── comparaisons/  # Pages de comparaison
│   │   ├── components/        # Composants réutilisables
│   │   ├── hooks/             # Hooks React personnalisés
│   │   └── lib/               # Bibliothèques et utilitaires
│   │       ├── datasheet-analyzer.js    # Analyse des datasheets
│   │       ├── cps-analyzer.js          # Analyse des CPS
│   │       ├── comparison-engine.js     # Moteur de comparaison
│   │       └── pdf-report-generator.js  # Génération de rapports PDF
│   ├── .env.local             # Variables d'environnement locales
│   ├── package.json           # Dépendances et scripts
│   └── wrangler.toml          # Configuration Cloudflare Workers
└── docs/                      # Documentation
    ├── analyse_besoins.md     # Analyse des besoins
    ├── architecture_systeme.md # Architecture du système
    └── modeles_base_donnees.md # Modèles de base de données
```

## Fonctionnalités principales

### Gestion des produits

L'application permet de gérer un catalogue de produits médicaux avec leurs caractéristiques techniques :

1. **Ajout de produits** : Importez des datasheets au format PDF pour extraire automatiquement les caractéristiques techniques.
2. **Modification de produits** : Modifiez manuellement les caractéristiques extraites si nécessaire.
3. **Visualisation des produits** : Consultez la liste des produits et leurs caractéristiques.

### Gestion des CPS

L'application permet de gérer les Cahiers des Prescriptions Spéciales :

1. **Import de CPS** : Importez des CPS au format PDF pour extraire automatiquement les lots et les exigences techniques.
2. **Analyse des CPS** : Analysez les exigences techniques et identifiez les caractéristiques correspondantes.
3. **Visualisation des CPS** : Consultez la liste des CPS et leurs exigences.

### Comparaison et rapports

L'application permet de comparer les exigences des CPS avec les caractéristiques des produits :

1. **Création de comparaisons** : Sélectionnez un CPS et un ou plusieurs produits à comparer.
2. **Visualisation des résultats** : Consultez les résultats de la comparaison avec un score global et des détails par exigence.
3. **Génération de rapports** : Générez des rapports PDF de conformité pour les soumissions d'appels d'offres.

## Dépannage

### Problèmes courants

#### L'application ne démarre pas

Vérifiez que toutes les dépendances sont installées :

```bash
npm install
```

Vérifiez que les ports requis sont disponibles (3000 par défaut).

#### Erreurs lors de l'analyse des PDF

Assurez-vous que les fichiers PDF ne sont pas corrompus ou protégés par mot de passe.

#### Erreurs lors de la génération des rapports PDF

Vérifiez que WeasyPrint est correctement installé :

```bash
weasyprint --version
```

Si WeasyPrint n'est pas reconnu, réinstallez-le :

```bash
pip3 install weasyprint
```

### Journaux d'erreurs

Les journaux d'erreurs sont disponibles dans la console du navigateur et dans la console du serveur.

## FAQ

### Comment ajouter une nouvelle modalité ?

Pour ajouter une nouvelle modalité, vous devez :

1. Ajouter la modalité dans la table `modalities` de la base de données
2. Créer les catégories de caractéristiques pour cette modalité
3. Définir les caractéristiques techniques pour cette modalité
4. Ajouter les patterns de reconnaissance dans le module d'analyse des datasheets
5. Ajouter les patterns de reconnaissance dans le module d'analyse des CPS

### Comment personnaliser les rapports PDF ?

Les rapports PDF sont générés à partir de templates HTML avec des styles CSS. Pour personnaliser l'apparence des rapports, modifiez la méthode `getDefaultStyles()` dans le fichier `src/lib/pdf-report-generator.js`.

### L'application peut-elle fonctionner hors ligne ?

Oui, l'application peut fonctionner hors ligne une fois installée. Cependant, certaines fonctionnalités comme la mise à jour des dépendances nécessitent une connexion Internet.

### Comment sauvegarder les données ?

Les données sont stockées dans une base de données SQLite. Pour sauvegarder les données, copiez le fichier de base de données (généralement situé dans `.wrangler/state/v3/d1/DB/db.sqlite`).

### Comment mettre à jour l'application ?

Pour mettre à jour l'application, suivez ces étapes :

1. Sauvegardez vos données
2. Téléchargez la dernière version de l'application
3. Remplacez les fichiers existants par les nouveaux
4. Exécutez `npm install` pour mettre à jour les dépendances
5. Exécutez `npx wrangler d1 migrations apply DB --local` pour appliquer les nouvelles migrations

## Support et contact

Pour toute question ou problème, veuillez contacter le support technique à l'adresse support@exemple.com.
