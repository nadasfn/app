# Modèles de Base de Données pour l'Application de Réponse aux Appels d'Offres

## Introduction

Ce document présente les modèles de base de données pour l'application de réponse aux appels d'offres, spécifiquement conçue pour comparer automatiquement les exigences des CPS (Cahiers des Prescriptions Spéciales) avec les caractéristiques techniques des produits d'imagerie médicale.

Après analyse des datasheets fournis pour les trois modalités médicales (amplificateurs de brillance, mammographes et tables de radiologie télécommandées) et de l'exemple de CPS, nous avons identifié les structures de données nécessaires pour permettre une comparaison efficace et la génération de rapports de conformité.

## Structure Générale de la Base de Données

La base de données D1 (SQLite) via Cloudflare Workers sera organisée selon les modèles suivants :

### 1. Modèle Utilisateur

```sql
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  role TEXT CHECK (role IN ('admin', 'commercial', 'technique', 'gestionnaire')) NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. Modèles pour les Produits et Caractéristiques

#### 2.1 Table des Modalités

```sql
CREATE TABLE modalities (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertion des trois modalités principales
INSERT INTO modalities (id, name, description) VALUES 
('amplificateur', 'Amplificateur de Brillance', 'Systèmes d''imagerie par rayons X en temps réel'),
('mammographe', 'Mammographe', 'Appareils spécialisés pour l''imagerie du sein'),
('table_radio', 'Table de Radiologie Télécommandée', 'Équipements pour examens radiologiques polyvalents');
```

#### 2.2 Table des Produits

```sql
CREATE TABLE products (
  id TEXT PRIMARY KEY,
  modality_id TEXT NOT NULL REFERENCES modalities(id),
  manufacturer TEXT NOT NULL,
  model TEXT NOT NULL,
  version TEXT,
  description TEXT,
  datasheet_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(manufacturer, model, version)
);
```

#### 2.3 Table des Catégories de Caractéristiques

```sql
CREATE TABLE characteristic_categories (
  id TEXT PRIMARY KEY,
  modality_id TEXT NOT NULL REFERENCES modalities(id),
  name TEXT NOT NULL,
  description TEXT,
  display_order INTEGER NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(modality_id, name)
);

-- Insertion des catégories pour les amplificateurs de brillance
INSERT INTO characteristic_categories (id, modality_id, name, description, display_order) VALUES 
('ampli_general', 'amplificateur', 'Caractéristiques Générales', 'Informations générales sur l''appareil', 1),
('ampli_generator', 'amplificateur', 'Générateur Haute Fréquence', 'Caractéristiques du générateur', 2),
('ampli_tube', 'amplificateur', 'Tube à Rayons X', 'Spécifications du tube à rayons X', 3),
('ampli_detector', 'amplificateur', 'Détecteur', 'Caractéristiques du détecteur d''image', 4),
('ampli_mechanics', 'amplificateur', 'Mécanique', 'Caractéristiques mécaniques et mouvements', 5),
('ampli_software', 'amplificateur', 'Logiciel', 'Fonctionnalités logicielles', 6),
('ampli_dose', 'amplificateur', 'Gestion de Dose', 'Fonctionnalités de réduction de dose', 7);

-- Insertion des catégories pour les mammographes
INSERT INTO characteristic_categories (id, modality_id, name, description, display_order) VALUES 
('mammo_general', 'mammographe', 'Caractéristiques Générales', 'Informations générales sur l''appareil', 1),
('mammo_generator', 'mammographe', 'Générateur', 'Caractéristiques du générateur', 2),
('mammo_tube', 'mammographe', 'Tube à Rayons X', 'Spécifications du tube à rayons X', 3),
('mammo_detector', 'mammographe', 'Détecteur', 'Caractéristiques du détecteur numérique', 4),
('mammo_compression', 'mammographe', 'Système de Compression', 'Caractéristiques du système de compression', 5),
('mammo_biopsy', 'mammographe', 'Système de Biopsie', 'Caractéristiques du système de biopsie', 6),
('mammo_tomo', 'mammographe', 'Tomosynthèse', 'Caractéristiques de la tomosynthèse', 7),
('mammo_software', 'mammographe', 'Logiciel', 'Fonctionnalités logicielles', 8),
('mammo_dose', 'mammographe', 'Gestion de Dose', 'Fonctionnalités de réduction de dose', 9);

-- Insertion des catégories pour les tables de radiologie télécommandées
INSERT INTO characteristic_categories (id, modality_id, name, description, display_order) VALUES 
('table_general', 'table_radio', 'Caractéristiques Générales', 'Informations générales sur l''appareil', 1),
('table_generator', 'table_radio', 'Générateur', 'Caractéristiques du générateur', 2),
('table_tube', 'table_radio', 'Tube à Rayons X', 'Spécifications du tube à rayons X', 3),
('table_detector', 'table_radio', 'Détecteur', 'Caractéristiques du détecteur numérique', 4),
('table_mechanics', 'table_radio', 'Mécanique', 'Caractéristiques mécaniques et mouvements', 5),
('table_table', 'table_radio', 'Table', 'Caractéristiques de la table d''examen', 6),
('table_software', 'table_radio', 'Logiciel', 'Fonctionnalités logicielles', 7),
('table_dose', 'table_radio', 'Gestion de Dose', 'Fonctionnalités de réduction de dose', 8);
```

#### 2.4 Table des Caractéristiques Techniques

```sql
CREATE TABLE characteristic_definitions (
  id TEXT PRIMARY KEY,
  category_id TEXT NOT NULL REFERENCES characteristic_categories(id),
  name TEXT NOT NULL,
  description TEXT,
  unit TEXT,
  data_type TEXT CHECK (data_type IN ('text', 'number', 'boolean', 'enum')) NOT NULL,
  possible_values TEXT, -- Pour les types enum, liste de valeurs séparées par des virgules
  display_order INTEGER NOT NULL,
  is_required BOOLEAN DEFAULT FALSE,
  is_comparable BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(category_id, name)
);

-- Exemples d'insertion pour les amplificateurs de brillance
INSERT INTO characteristic_definitions (id, category_id, name, description, unit, data_type, display_order, is_required, is_comparable) VALUES 
('ampli_power', 'ampli_general', 'Puissance', 'Puissance maximale', 'kW', 'number', 1, TRUE, TRUE),
('ampli_inverter_freq', 'ampli_generator', 'Fréquence Inverseur', 'Fréquence de l''inverseur', 'kHz', 'number', 1, TRUE, TRUE),
('ampli_tube_voltage', 'ampli_tube', 'Tension du tube radiographique', 'Plage de tension du tube', 'kV', 'text', 1, TRUE, TRUE),
('ampli_tube_current', 'ampli_tube', 'Courant du tube fluoroscopique', 'Plage de courant en fluoroscopie', 'mA', 'text', 2, TRUE, TRUE),
('ampli_focal_spot', 'ampli_tube', 'Taille du foyer', 'Dimensions du foyer', 'mm', 'text', 3, TRUE, TRUE),
('ampli_anode_capacity', 'ampli_tube', 'Capacité thermique de l''anode', 'Capacité thermique', 'kHU', 'number', 4, TRUE, TRUE);

-- Exemples d'insertion pour les mammographes
INSERT INTO characteristic_definitions (id, category_id, name, description, unit, data_type, display_order, is_required, is_comparable) VALUES 
('mammo_detector_type', 'mammo_detector', 'Type de détecteur', 'Technologie du détecteur', '', 'text', 1, TRUE, TRUE),
('mammo_detector_size', 'mammo_detector', 'Taille du détecteur', 'Dimensions du détecteur', 'cm', 'text', 2, TRUE, TRUE),
('mammo_pixel_size', 'mammo_detector', 'Taille des pixels', 'Dimensions des pixels', 'μm', 'number', 3, TRUE, TRUE),
('mammo_tomo_capable', 'mammo_tomo', 'Capacité de tomosynthèse', 'Capable de tomosynthèse', '', 'boolean', 1, TRUE, TRUE),
('mammo_tomo_angle', 'mammo_tomo', 'Angle de tomosynthèse', 'Angle total de balayage', '°', 'number', 2, FALSE, TRUE),
('mammo_compression_force', 'mammo_compression', 'Force de compression', 'Force maximale de compression', 'N', 'number', 1, TRUE, TRUE);

-- Exemples d'insertion pour les tables de radiologie télécommandées
INSERT INTO characteristic_definitions (id, category_id, name, description, unit, data_type, display_order, is_required, is_comparable) VALUES 
('table_generator_power', 'table_generator', 'Puissance du générateur', 'Puissance maximale', 'kW', 'number', 1, TRUE, TRUE),
('table_tube_voltage', 'table_tube', 'Tension du tube', 'Plage de tension du tube', 'kV', 'text', 1, TRUE, TRUE),
('table_tube_current', 'table_tube', 'Courant du tube', 'Plage de courant', 'mA', 'text', 2, TRUE, TRUE),
('table_detector_type', 'table_detector', 'Type de détecteur', 'Technologie du détecteur', '', 'text', 1, TRUE, TRUE),
('table_detector_size', 'table_detector', 'Taille du détecteur', 'Dimensions du détecteur', 'cm', 'text', 2, TRUE, TRUE),
('table_table_height', 'table_table', 'Hauteur de la table', 'Plage de hauteur de la table', 'cm', 'text', 1, TRUE, TRUE),
('table_table_capacity', 'table_table', 'Capacité de charge', 'Poids maximal supporté', 'kg', 'number', 2, TRUE, TRUE);
```

#### 2.5 Table des Valeurs de Caractéristiques

```sql
CREATE TABLE product_characteristics (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  characteristic_id TEXT NOT NULL REFERENCES characteristic_definitions(id),
  value TEXT NOT NULL,
  source TEXT, -- Source de l'information (page du datasheet)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(product_id, characteristic_id)
);
```

### 3. Modèles pour les CPS et Exigences

#### 3.1 Table des CPS

```sql
CREATE TABLE cps_documents (
  id TEXT PRIMARY KEY,
  reference TEXT NOT NULL,
  title TEXT NOT NULL,
  organization TEXT NOT NULL,
  deadline TIMESTAMP,
  document_url TEXT,
  status TEXT CHECK (status IN ('nouveau', 'analysé', 'en_cours', 'terminé')) NOT NULL DEFAULT 'nouveau',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 3.2 Table des Lots

```sql
CREATE TABLE cps_lots (
  id TEXT PRIMARY KEY,
  cps_id TEXT NOT NULL REFERENCES cps_documents(id),
  lot_number TEXT NOT NULL,
  designation TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  modality_id TEXT REFERENCES modalities(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(cps_id, lot_number)
);
```

#### 3.3 Table des Exigences

```sql
CREATE TABLE cps_requirements (
  id TEXT PRIMARY KEY,
  lot_id TEXT NOT NULL REFERENCES cps_lots(id),
  category TEXT,
  description TEXT NOT NULL,
  importance TEXT CHECK (importance IN ('obligatoire', 'optionnel')) NOT NULL DEFAULT 'obligatoire',
  section TEXT,
  page INTEGER,
  characteristic_id TEXT REFERENCES characteristic_definitions(id),
  expected_value TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 4. Modèles pour les Comparaisons et Rapports

#### 4.1 Table des Comparaisons

```sql
CREATE TABLE comparisons (
  id TEXT PRIMARY KEY,
  cps_id TEXT NOT NULL REFERENCES cps_documents(id),
  name TEXT NOT NULL,
  description TEXT,
  status TEXT CHECK (status IN ('brouillon', 'validé', 'rejeté')) NOT NULL DEFAULT 'brouillon',
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### 4.2 Table des Détails de Comparaison par Lot

```sql
CREATE TABLE comparison_lot_details (
  id TEXT PRIMARY KEY,
  comparison_id TEXT NOT NULL REFERENCES comparisons(id),
  lot_id TEXT NOT NULL REFERENCES cps_lots(id),
  product_id TEXT NOT NULL REFERENCES products(id),
  overall_score REAL,
  mandatory_requirements_met INTEGER,
  total_mandatory_requirements INTEGER,
  optional_requirements_met INTEGER,
  total_optional_requirements INTEGER,
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(comparison_id, lot_id, product_id)
);
```

#### 4.3 Table des Détails de Comparaison par Exigence

```sql
CREATE TABLE comparison_requirement_details (
  id TEXT PRIMARY KEY,
  comparison_lot_id TEXT NOT NULL REFERENCES comparison_lot_details(id),
  requirement_id TEXT NOT NULL REFERENCES cps_requirements(id),
  product_characteristic_id TEXT REFERENCES product_characteristics(id),
  is_compliant BOOLEAN NOT NULL,
  compliance_notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(comparison_lot_id, requirement_id)
);
```

#### 4.4 Table des Rapports

```sql
CREATE TABLE reports (
  id TEXT PRIMARY KEY,
  comparison_id TEXT NOT NULL REFERENCES comparisons(id),
  title TEXT NOT NULL,
  format TEXT CHECK (format IN ('pdf', 'excel', 'html')) NOT NULL DEFAULT 'pdf',
  file_url TEXT,
  created_by TEXT NOT NULL REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## Caractéristiques Techniques Spécifiques par Modalité

Basé sur l'analyse des datasheets fournis, nous avons identifié les caractéristiques techniques clés pour chaque modalité. Ces caractéristiques seront utilisées pour la comparaison avec les exigences des CPS.

### 1. Amplificateurs de Brillance (basé sur PLX118F-PLUS-A et Arcovis 3000)

- **Caractéristiques Générales**
  - Puissance (kW)
  - Type de système (mobile, fixe)
  - Applications cliniques

- **Générateur Haute Fréquence**
  - Fréquence inverseur (kHz)
  - Puissance maximale (kW)

- **Tube à Rayons X**
  - Tension radiographique (kV)
  - Courant radiographique (mA)
  - Tension fluoroscopique (kV)
  - Courant fluoroscopique (mA)
  - Taille du foyer (mm)
  - Capacité thermique de l'anode (kHU)
  - Type d'anode (fixe, rotative)

- **Détecteur**
  - Type de détecteur
  - Taille du champ de vision
  - Matrice d'image
  - Profondeur de bit

- **Mécanique**
  - Mouvements du bras en C
  - Rotation orbitale (°)
  - Rotation latérale (°)
  - Mouvement vertical (cm)

- **Logiciel**
  - Fonctionnalités de traitement d'image
  - Capacités de stockage
  - Connectivité DICOM

- **Gestion de Dose**
  - Fonctionnalités de réduction de dose
  - Affichage de dose

### 2. Mammographes (basé sur Pinkview et Melody)

- **Caractéristiques Générales**
  - Type de système
  - Applications cliniques

- **Générateur**
  - Puissance (kW)
  - Plage de tension (kV)
  - Plage de courant (mA)

- **Tube à Rayons X**
  - Type d'anode
  - Matériau de l'anode
  - Filtration
  - Taille du foyer (mm)

- **Détecteur**
  - Type de détecteur
  - Taille du détecteur (cm)
  - Taille des pixels (μm)
  - Matrice d'image
  - Profondeur de bit

- **Système de Compression**
  - Force de compression (N)
  - Types de palettes de compression
  - Compression automatique

- **Système de Biopsie**
  - Compatibilité avec systèmes de biopsie
  - Types de biopsie supportés

- **Tomosynthèse**
  - Capacité de tomosynthèse
  - Angle de balayage (°)
  - Temps d'acquisition (s)

- **Logiciel**
  - Algorithmes de traitement d'image
  - Outils de diagnostic assisté par ordinateur
  - Connectivité DICOM

- **Gestion de Dose**
  - Fonctionnalités de réduction de dose
  - Affichage de dose

### 3. Tables de Radiologie Télécommandées (basé sur PLD et Apollo)

- **Caractéristiques Générales**
  - Type de système
  - Applications cliniques

- **Générateur**
  - Puissance (kW)
  - Plage de tension (kV)
  - Plage de courant (mA)

- **Tube à Rayons X**
  - Type d'anode
  - Capacité thermique (kHU)
  - Taille du foyer (mm)
  - Filtration

- **Détecteur**
  - Type de détecteur
  - Taille du détecteur (cm)
  - Taille des pixels (μm)
  - Matrice d'image
  - DQE (%)

- **Mécanique**
  - Plage de mouvement de la table
  - Inclinaison de la table (°)
  - Hauteur minimale/maximale (cm)
  - Capacité de charge (kg)

- **Table**
  - Dimensions de la table
  - Matériau de la table
  - Distance source-détecteur (cm)

- **Logiciel**
  - Fonctionnalités de traitement d'image
  - Modes d'acquisition
  - Connectivité DICOM

- **Gestion de Dose**
  - Fonctionnalités de réduction de dose
  - Affichage de dose

## Structure du CPS et Exigences

Basé sur l'analyse du CPS fourni (CPS 96-2024-2), nous avons identifié la structure suivante pour les exigences techniques :

1. Le CPS est organisé en lots numérotés (01, 02, 03, etc.)
2. Chaque lot correspond à un équipement spécifique (IRM, Scanner TDM, Mammographe, Table de Radiologie, etc.)
3. Pour chaque lot, des spécifications techniques détaillées sont fournies à l'article 33
4. Les exigences peuvent être obligatoires ou optionnelles
5. Les exigences sont généralement organisées par catégories (caractéristiques générales, tube à rayons X, détecteur, etc.)

Cette structure est reflétée dans les modèles de données ci-dessus, permettant une comparaison efficace entre les exigences du CPS et les caractéristiques techniques des produits.

## Conclusion

Les modèles de base de données présentés dans ce document permettront de stocker et de gérer efficacement les informations nécessaires pour l'application de réponse aux appels d'offres. Ces modèles sont conçus pour être flexibles et évolutifs, permettant d'ajouter facilement de nouvelles modalités, caractéristiques ou exigences à l'avenir.

La prochaine étape consistera à développer l'interface utilisateur qui permettra d'interagir avec ces données, d'importer les datasheets, d'analyser les CPS, de réaliser les comparaisons automatiques et de générer les rapports de conformité.
