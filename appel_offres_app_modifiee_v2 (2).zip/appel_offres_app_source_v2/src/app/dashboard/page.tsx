
  use client
  
  import { Button } from "@/components/ui/button";
  import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
  import Link from "next/link";
  import { ArrowLeft, LayoutDashboard, FilePlus2 } from "lucide-react";
  
  export default function DashboardPage() {
    // Ici, vous pourriez récupérer des informations spécifiques à l"utilisateur connecté
  
    return (
      <div className="flex flex-col items-center min-h-screen bg-background text-foreground p-4 pt-20 md:pt-24">
        <header className="absolute top-0 left-0 p-4 md:p-6">
          <Link href="/" legacyBehavior>
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour à l\"accueil
            </Button>
          </Link>
        </header>
        {/* Vous pourriez ajouter un bouton de déconnexion ici aussi */}
  
        <main className="w-full max-w-4xl space-y-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div className="flex items-center space-x-3">
              <LayoutDashboard className="h-10 w-10 text-primary" />
              <h1 className="text-3xl font-bold">Tableau de Bord</h1>
            </div>
            <Link href="/upload-cps" legacyBehavior>
              <Button>
                <FilePlus2 className="mr-2 h-4 w-4" />
                Analyser un nouveau CPS
              </Button>
            </Link>
          </div>
  
          <Card>
            <CardHeader>
              <CardTitle>Bienvenue sur votre espace personnalisé.</CardTitle>
              <CardDescription>Gérez vos analyses CPS et consultez vos rapports.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Cette section est en cours de développement. Prochainement, vous pourrez visualiser ici :
              </p>
              <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                <li>Vos fichiers CPS récemment téléversés et leur statut d\"analyse.</li>
                <li>Les rapports de comparaison générés.</li>
                <li>Des statistiques sur vos activités.</li>
                <li>Les paramètres de votre compte.</li>
              </ul>
              <div className="border-t pt-4 mt-4">
                  <h3 className="font-semibold mb-2">Actions rapides :</h3>
                   <div className="flex gap-2">
                      <Button variant="secondary" disabled>Mes Rapports (Bientôt)</Button>
                      <Button variant="secondary" disabled>Mon Compte (Bientôt)</Button>
                   </div>
              </div>
            </CardContent>
          </Card>
  
          {/* D"autres sections/cartes pourraient être ajoutées ici */}
        </main>
  
        <footer className="w-full text-center p-4 md:p-6 mt-12 text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Votre Entreprise. Tous droits réservés.</p>
        </footer>
      </div>
    );
  }
  
