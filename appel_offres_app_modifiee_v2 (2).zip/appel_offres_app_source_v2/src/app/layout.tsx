import type { Metadata } from "next"
import { Inter } from "next/font/google" // Ou une autre police de votre choix
import "./globals.css" // Assurez-vous que ce chemin est correct

const inter = Inter({ subsets: ["latin"], variable: "--font-sans" })

export const metadata: Metadata = {
  title: "Assistant Appels d"Offres",
  description: "Optimisez la gestion de vos réponses aux appels d"offres.",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className="dark"> {/* Applique le mode sombre par défaut */}
      <body className={`min-h-screen bg-background font-sans antialiased ${inter.variable}`}>
        {children}
      </body>
    </html>
  )
}

