
  use client
  
  import { useState, FormEvent } from "react";
  import { Button } from "@/components/ui/button";
  import { Input } from "@/components/ui/input";
  import { Label } from "@/components/ui/label";
  import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
  import Link from "next/link";
  import { useRouter } from "next/navigation"; // Pour la redirection
  import { ArrowLeft, LogIn } from "lucide-react";
  
  export default function LoginPage() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const router = useRouter();
  
    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      setIsLoading(true);
      setErrorMessage(null);
  
      // Simulation d"une connexion
      await new Promise(resolve => setTimeout(resolve, 1000));
  
      // Logique de connexion (à remplacer par votre vraie logique d"authentification)
      if (email === "test@example.com" && password === "password") {
        // Connexion réussie (simulation)
        router.push("/dashboard"); // Rediriger vers le tableau de bord
      } else {
        setErrorMessage("Adresse e-mail ou mot de passe incorrect.");
      }
      setIsLoading(false);
    };
  
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground p-4">
        <header className="absolute top-0 left-0 p-4 md:p-6">
          <Link href="/" legacyBehavior>
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour à l\"accueil
            </Button>
          </Link>
        </header>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <LogIn className="mx-auto h-12 w-12 text-primary mb-4" />
            <CardTitle className="text-2xl">Connexion</CardTitle>
            <CardDescription>Accédez à votre espace personnalisé pour gérer vos appels d\"offres.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <Label htmlFor="email">Adresse e-mail</Label>
                <Input id="email" type="email" placeholder="vous@exemple.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <Label htmlFor="password">Mot de passe</Label>
                <Input id="password" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} required />
              </div>
              {errorMessage && <p className="text-sm text-destructive">{errorMessage}</p>}
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Connexion en cours..." : "Se connecter"}
              </Button>
            </form>
            <p className="mt-6 text-center text-sm">
              Pas encore de compte ?{" "}
              <Link href="/register" className="font-medium text-primary hover:underline">
                S\"inscrire
              </Link>
            </p>
          </CardContent>
        </Card>
        <footer className="absolute bottom-0 w-full text-center p-4 md:p-6 text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Votre Entreprise. Tous droits réservés.</p>
        </footer>
      </div>
    );
  }
  
