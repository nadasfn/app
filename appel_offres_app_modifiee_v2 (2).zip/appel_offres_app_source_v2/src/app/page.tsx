
'use client'

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from 'next/link'
import Image from 'next/image'

export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground p-4">
      <header className="absolute top-0 left-0 p-4 md:p-6">
        <Link href="/" className="flex items-center space-x-2">
          <Image src="/logo_placeholder.svg" alt="Logo" width={40} height={40} />
          <span className="font-semibold text-lg">Assistant AO</span>
        </Link>
      </header>
      <header className="absolute top-0 right-0 p-4 md:p-6">
        <Link href="/login" legacyBehavior>
          <Button variant="outline">Connexion</Button>
        </Link>
      </header>

      <main className="flex flex-col items-center text-center space-y-8 max-w-2xl">
        <Image src="/logo_placeholder.svg" alt="Logo Principal" width={120} height={120} className="mb-6" />
        <h1 className="text-4xl md:text-5xl font-bold">
          Bienvenue sur votre Assistant d"Appels d"Offres
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground">
          Optimisez la gestion de vos réponses aux appels d"offres grâce à une analyse automatisée et précise des Cahiers des Prescriptions Spéciales (CPS).
        </p>
        <p className="text-md text-muted-foreground">
          Notre plateforme vous permet de téléverser vos documents CPS, de les comparer avec notre base de données de fiches techniques produits, et de générer des rapports de conformité détaillés. Simplifiez votre processus et gagnez en efficacité.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <Link href="/upload-cps" legacyBehavior>
            <Button size="lg" className="w-full sm:w-auto">Commencer : Uploader un CPS</Button>
          </Link>
          <Link href="/dashboard" legacyBehavior>
            <Button variant="secondary" size="lg" className="w-full sm:w-auto">Accéder au Tableau de Bord</Button>
          </Link>
        </div>
      </main>

      <footer className="absolute bottom-0 w-full text-center p-4 md:p-6 text-sm text-muted-foreground">
        <p>© {new Date().getFullYear()} Votre Entreprise. Tous droits réservés.</p>
        <p>Développé avec soin pour optimiser vos performances.</p>
      </footer>
    </div>
  )
}

