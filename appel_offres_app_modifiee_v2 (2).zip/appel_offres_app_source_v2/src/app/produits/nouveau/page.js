// Interface pour l'import et l'analyse des datasheets
// Fichier: src/app/produits/nouveau/page.js

import React from 'react';
import Link from 'next/link';

export default function NouveauProduit() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* En-tête */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Ajouter un nouveau produit
            </h1>
            <p className="mt-1 text-sm text-gray-600">
              Importez un datasheet et extrayez les caractéristiques techniques du produit
            </p>
          </div>
          <div>
            <Link href="/produits" className="text-blue-600 hover:text-blue-800">
              Retour à la liste des produits
            </Link>
          </div>
        </div>
      </header>

      {/* Contenu principal */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:grid md:grid-cols-3 md:gap-6">
          <div className="md:col-span-1">
            <div className="px-4 sm:px-0">
              <h3 className="text-lg font-medium leading-6 text-gray-900">Informations du produit</h3>
              <p className="mt-1 text-sm text-gray-600">
                Commencez par sélectionner la modalité et télécharger le datasheet du produit.
                Le système analysera automatiquement le document pour extraire les caractéristiques techniques.
              </p>
              <div className="mt-6">
                <h4 className="text-md font-medium text-gray-900">Instructions</h4>
                <ul className="mt-2 text-sm text-gray-600 space-y-1 list-disc list-inside">
                  <li>Sélectionnez la modalité du produit</li>
                  <li>Téléchargez le datasheet au format PDF</li>
                  <li>Vérifiez et complétez les caractéristiques extraites</li>
                  <li>Enregistrez le produit dans la base de données</li>
                </ul>
              </div>
              <div className="mt-6">
                <h4 className="text-md font-medium text-gray-900">Formats supportés</h4>
                <p className="mt-2 text-sm text-gray-600">
                  L'application supporte actuellement les datasheets au format PDF.
                </p>
              </div>
            </div>
          </div>
          <div className="mt-5 md:mt-0 md:col-span-2">
            <form action="#" method="POST">
              <div className="shadow sm:rounded-md sm:overflow-hidden">
                <div className="px-4 py-5 bg-white space-y-6 sm:p-6">
                  {/* Modalité */}
                  <div>
                    <label htmlFor="modalite" className="block text-sm font-medium text-gray-700">
                      Modalité
                    </label>
                    <select
                      id="modalite"
                      name="modalite"
                      className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                    >
                      <option value="">Sélectionnez une modalité</option>
                      <option value="amplificateur">Amplificateur de Brillance</option>
                      <option value="mammographe">Mammographe</option>
                      <option value="table_radio">Table de Radiologie Télécommandée</option>
                    </select>
                  </div>

                  {/* Fabricant */}
                  <div>
                    <label htmlFor="fabricant" className="block text-sm font-medium text-gray-700">
                      Fabricant
                    </label>
                    <input
                      type="text"
                      name="fabricant"
                      id="fabricant"
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="Nom du fabricant"
                    />
                  </div>

                  {/* Modèle */}
                  <div>
                    <label htmlFor="modele" className="block text-sm font-medium text-gray-700">
                      Modèle
                    </label>
                    <input
                      type="text"
                      name="modele"
                      id="modele"
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="Nom du modèle"
                    />
                  </div>

                  {/* Version */}
                  <div>
                    <label htmlFor="version" className="block text-sm font-medium text-gray-700">
                      Version
                    </label>
                    <input
                      type="text"
                      name="version"
                      id="version"
                      className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                      placeholder="Version du produit (optionnel)"
                    />
                  </div>

                  {/* Description */}
                  <div>
                    <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                      Description
                    </label>
                    <div className="mt-1">
                      <textarea
                        id="description"
                        name="description"
                        rows={3}
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md"
                        placeholder="Description du produit"
                      />
                    </div>
                    <p className="mt-2 text-sm text-gray-500">
                      Brève description du produit et de ses principales caractéristiques.
                    </p>
                  </div>

                  {/* Téléchargement du datasheet */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Datasheet
                    </label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                      <div className="space-y-1 text-center">
                        <svg
                          className="mx-auto h-12 w-12 text-gray-400"
                          stroke="currentColor"
                          fill="none"
                          viewBox="0 0 48 48"
                          aria-hidden="true"
                        >
                          <path
                            d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02"
                            strokeWidth={2}
                            strokeLinecap="round"
                            strokeLinejoin="round"
                          />
                        </svg>
                        <div className="flex text-sm text-gray-600">
                          <label
                            htmlFor="file-upload"
                            className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                          >
                            <span>Télécharger un fichier</span>
                            <input id="file-upload" name="file-upload" type="file" className="sr-only" />
                          </label>
                          <p className="pl-1">ou glisser-déposer</p>
                        </div>
                        <p className="text-xs text-gray-500">PDF jusqu'à 10MB</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
                  <button
                    type="submit"
                    className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Analyser le datasheet
                  </button>
                </div>
              </div>
            </form>

            {/* Section pour les caractéristiques extraites (initialement cachée) */}
            <div className="hidden mt-6 shadow sm:rounded-md sm:overflow-hidden">
              <div className="px-4 py-5 bg-white space-y-6 sm:p-6">
                <h3 className="text-lg font-medium leading-6 text-gray-900">Caractéristiques techniques extraites</h3>
                <p className="text-sm text-gray-600">
                  Les caractéristiques suivantes ont été extraites automatiquement du datasheet. Veuillez vérifier et compléter si nécessaire.
                </p>

                {/* Caractéristiques générales */}
                <div>
                  <h4 className="text-md font-medium text-gray-900">Caractéristiques générales</h4>
                  <div className="mt-2 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="puissance" className="block text-sm font-medium text-gray-700">
                        Puissance (kW)
                      </label>
                      <input
                        type="text"
                        name="puissance"
                        id="puissance"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="5"
                      />
                    </div>
                    <div>
                      <label htmlFor="type_systeme" className="block text-sm font-medium text-gray-700">
                        Type de système
                      </label>
                      <input
                        type="text"
                        name="type_systeme"
                        id="type_systeme"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="Mobile"
                      />
                    </div>
                  </div>
                </div>

                {/* Générateur */}
                <div>
                  <h4 className="text-md font-medium text-gray-900">Générateur</h4>
                  <div className="mt-2 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="frequence_inverseur" className="block text-sm font-medium text-gray-700">
                        Fréquence inverseur (kHz)
                      </label>
                      <input
                        type="text"
                        name="frequence_inverseur"
                        id="frequence_inverseur"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="110"
                      />
                    </div>
                    <div>
                      <label htmlFor="puissance_max" className="block text-sm font-medium text-gray-700">
                        Puissance maximale (kW)
                      </label>
                      <input
                        type="text"
                        name="puissance_max"
                        id="puissance_max"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="5"
                      />
                    </div>
                  </div>
                </div>

                {/* Tube à rayons X */}
                <div>
                  <h4 className="text-md font-medium text-gray-900">Tube à rayons X</h4>
                  <div className="mt-2 grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="tension_radiographique" className="block text-sm font-medium text-gray-700">
                        Tension radiographique (kV)
                      </label>
                      <input
                        type="text"
                        name="tension_radiographique"
                        id="tension_radiographique"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="40-120"
                      />
                    </div>
                    <div>
                      <label htmlFor="courant_radiographique" className="block text-sm font-medium text-gray-700">
                        Courant radiographique (mA)
                      </label>
                      <input
                        type="text"
                        name="courant_radiographique"
                        id="courant_radiographique"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="0.5-100"
                      />
                    </div>
                    <div>
                      <label htmlFor="taille_foyer" className="block text-sm font-medium text-gray-700">
                        Taille du foyer (mm)
                      </label>
                      <input
                        type="text"
                        name="taille_foyer"
                        id="taille_foyer"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="0.3/0.6"
                      />
                    </div>
                    <div>
                      <label htmlFor="capacite_thermique" className="block text-sm font-medium text-gray-700">
                        Capacité thermique de l'anode (kHU)
                      </label>
                      <input
                        type="text"
                        name="capacite_thermique"
                        id="capacite_thermique"
                        className="mt-1 focus:ring-blue-500 focus:border-blue-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        value="300"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="px-4 py-3 bg-gray-50 text-right sm:px-6">
                <button
                  type="button"
                  className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                >
                  Enregistrer le produit
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
