
  use client
  
  import { useState, FormEvent } from "react";
  import { Button } from "@/components/ui/button";
  import { Input } from "@/components/ui/input";
  import { Label } from "@/components/ui/label";
  import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
  import Link from "next/link";
  import { useRouter } from "next/navigation";
  import { ArrowLeft, UserPlus } from "lucide-react";
  
  export default function RegisterPage() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const router = useRouter();
  
    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      if (password !== confirmPassword) {
        setErrorMessage("Les mots de passe ne correspondent pas.");
        return;
      }
      setIsLoading(true);
      setErrorMessage(null);
  
      // Simulation d"une inscription
      await new Promise(resolve => setTimeout(resolve, 1000));
  
      // Logique d"inscription (à remplacer par votre vraie logique)
      console.log("Inscription simulée pour :", email);
      // Idéalement, rediriger vers la page de connexion ou directement au dashboard après inscription réussie
      router.push("/login?registered=true");
  
      setIsLoading(false);
    };
  
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground p-4">
        <header className="absolute top-0 left-0 p-4 md:p-6">
          <Link href="/" legacyBehavior>
            <Button variant="outline" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Retour à l\"accueil
            </Button>
          </Link>
        </header>
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <UserPlus className="mx-auto h-12 w-12 text-primary mb-4" />
            <CardTitle className="text-2xl">Créer un Compte</CardTitle>
            <CardDescription>Rejoignez notre plateforme pour simplifier la gestion de vos appels d\"offres.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-1">
                <Label htmlFor="email">Adresse e-mail</Label>
                <Input id="email" type="email" placeholder="vous@exemple.com" value={email} onChange={(e) => setEmail(e.target.value)} required />
              </div>
              <div className="space-y-1">
                <Label htmlFor="password">Mot de passe</Label>
                <Input id="password" type="password" placeholder="•••••••• (8+ caractères)" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
              </div>
              <div className="space-y-1">
                <Label htmlFor="confirm-password">Confirmer le mot de passe</Label>
                <Input id="confirm-password" type="password" placeholder="••••••••" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
              </div>
              {errorMessage && <p className="text-sm text-destructive">{errorMessage}</p>}
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? "Inscription en cours..." : "S\"inscrire"}
              </Button>
            </form>
            <p className="mt-6 text-center text-sm">
              Déjà un compte ?{" "}
              <Link href="/login" className="font-medium text-primary hover:underline">
                Se connecter
              </Link>
            </p>
          </CardContent>
        </Card>
        <footer className="absolute bottom-0 w-full text-center p-4 md:p-6 text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Votre Entreprise. Tous droits réservés.</p>
        </footer>
      </div>
    );
  }
  
